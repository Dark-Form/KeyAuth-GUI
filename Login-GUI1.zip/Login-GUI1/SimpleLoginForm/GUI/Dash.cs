﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleLoginForm
{
    public partial class Dash : Form
    {
        public Dash()
        {
            InitializeComponent();
        }

        private void DiscordBtn_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://discordapp.com");
        }

        private void guna2ControlBox1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        public string expirydaysleft()
        {
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Local);
            dtDateTime = dtDateTime.AddSeconds(long.Parse(Login.KeyAuthApp.user_data.subscriptions[0].expiry)).ToLocalTime();
            TimeSpan difference = dtDateTime - DateTime.Now;
            return Convert.ToString(difference.Days + " Days " + difference.Hours + " Hours and " + difference.Minutes + " Minutes Left");
        }
        private void Dash_Load(object sender, EventArgs e)
        {
            expiry.Text = expirydaysleft();
            product.Text = Login.KeyAuthApp.user_data.subscriptions[0].subscription;
        }

        private void expiry_Click(object sender, EventArgs e)
        {

        }
    }
}
